## Dataset description

this folder contains the dataset accompanying the paper "Efficient Binary-Level Coverage Ananalysis".
The data files are distributed in the csv format. We briefly describe their
schema in the following.

---------------------------------------

File: bcov.test.results.csv

Description: this data provides details about the test suite runs used to
evaluate performance overhead. It has the following schema:

- compiler: compiler used to produce the binary
- build: build type
- package: module name
- tag: the type of run. Which can be either original (orig), instrumented
 with leaf-node policy (all), instrumented with any-node policy (any).
 Also, runs under DBI tools are available but should NOT be considered.
- timestamp
- elapsed-time: time taken to complete the test suite run (seconds)
- merge-time: time needed to merge bcov coverage files (seconds).
 One merged file can be used to produce a coverage report for the entire
 test suite.
- data-size: total size in KB of bcov coverage data
- file-count: total number of files dumped by bcov

---------------------------------------

File: dbi.test.results.csv

Description: this is similar to the previous file but focuses only on the
performance overhead of DBI tools. It is used to produce Figure 9.

---------------------------------------

File: complete-sb-results.csv

Description: we provide in this dataset the details about more than 1.6
million functions instrumented by bcov. Also, we evaluated the optimiality
of Agrawal's probe pruning technique, as implemented in bcov, to that in
implemented in Tikir et. al [37] and LLVM's sancov. These details are not
relevant for this submission. This dataset has the following schema:

- binary: binary name
- compiler: used compiler
- build: build type
- function: the address of the instrumented function
- instructions: total number of instructions in the function
- bb: total number of basic blocks
- sb: total number of super blocks
- all-test: total number of super blocks probed under the leaf-node policy
- any-test: number of super blocks probed *only* in the any-node policy
- any-test-total: total number of super blocks probed under any-node policy
- sancov-probe:
- sancov-redundant:
- sancov-missed:
- sancov-none:
- tikir-probe:
- tikir-redundant:
- tikir-missed:
- tikir-none:

---------------------------------------

File: patch.results.final.csv

Description: this dataset provides details about the patching results for
each binary. For example, it describes the number of probes of each probe
type described in Table 3. It has the following schema:

- compiler: used compiler
- build: build type
- package: binary name
- code-overhead: internal metric
- text-ratio: internal metric
- mode: instrumentation policy
- link: number of probes of this type (internal)
- return: number of probes of this type
- long-jmp: number of probes of this type
- long-call: number of probes of this type
- jumptab: number of probes of this type
- short-call: number of probes of this type
- short-jmp: number of probes of this type
- inner-bb: number of probes of this type
- long-cond:number of probes of this type
- short-cond: number of probes of this type
- guest: number of probes of this type
- nohost: number of guests that could not be hosted
- plain-host: number of guests that are hosted in an intact basic block
- replaced: internal metric
- hosts: total number of hosts
- probe-count: total number of probes for this binary
- patch-code-size: size of patch code
- coverage-update-size: size of coverage update code only
- patch-data-size: size of coverage data in bytes
- pad-link: the following describe the padding after each probe type
- pad-return:
- pad-long-jmp:
- pad-long-call:
- pad-jumptab:
- pad-short-call:
- pad-short-jmp:
- pad-inner-bb:
- pad-long-cond:
- pad-short-cond:
- pad-guest:
- pad-nohost:
- pad-plain-host:

---------------------------------------

File: jump-table.results.csv

Description: this file contains the dataset used to produce the comparison
between bcov and IDA Pro in terms of jump table analysis (Figure 8).
It has the following schema:

- binary: module name
- compiler: used compiler
- build: build type
- total: number of jump tables found by both bcov and IDA in the binary
- bcov: number of jump tables found by bcov and missed by IDA
- ida: number of jump tables found by IDA and missed by bcov

---------------------------------------

File: noreturn.results.csv

Description: this file contains the dataset used to compare
between bcov and IDA Pro in terms of non-return analysis. This data was only
highlighted not in the paper. It has the following schema:

- binary
- compiler
- build
- total: number of non-return functions found by both bcov and IDA in the binary
- bcov: number of non-return functions found by bcov and missed by IDA
- ida: number of non-return functions found by IDA and missed by bcov

---------------------------------------

File: bcov.coverage.accuracy.csv

Description: this file contains the dataset used in Table 5 to evaluate the
accuracy of bcov based on drcov traces. Each line describes a single test:

 - binary: binary name
 - bb: total number of basic blocks
 - inst: total number of instructions
 - tp_bb:
 - tp_inst:
 - fp_bb:
 - fp_inst
 - fn_bb
 - fn_inst
 - drcov_uniq: unique basic block heads reported by drcov
 - drcov_all: all basic blocks reported by drcov
 - precision: precision of this run
 - recall: recall of this run

True Positive (TP). False Positive (FP). False Negative (FN)
---------------------------------------

File: bcov-size-overhead.csv

Description: this file contains the dataset used to evaluate the size overhead
in Figure 7. It has the following schema:

  - binary: binary name
  - compiler: used compiler
  - build: build type
  - orig-image-size: original memory image size
  - all-image-size: leaf-node memory image size
  - any-image-size: any-node memory image size
  - orig-file-size: original file size
  - all-file-size: leaf-node file size
  - any-file-size: any-node file size
  - any-image-ratio: image size overhead relative to original
  - any-file-ratio: file size overhead relative to original

---------------------------------------

File: objdump-size-comparison.csv

Description: this file contains the dataset used to produce Figure 6 which compares
the size of our subjects to the popular binary objdump.

---------------------------------------

File: bcov-jump-tables-dist.csv

Description: this file contains the dataset describing the types of the jump tables
recovered by bcov in our binary subjects.

  - compiler:
  - build:
  - binary:
  - none: unknown type
  - soff8: signed 8-bit offset
  - soff16: signed 16-bit offset
  - soff32: signed 32-bit offset
  - uoff8: unsigned 8-bit offset
  - uoff16: unsigned 16-bit offset
  - abs32: absolute 32-bit address
  - abs64: absolute 64-bit address
  - sum: total number of jump tables
